const Form = document.getElementById("form")
const Form_Control = document.getElementById("form-control")
const User_Name = document.getElementById("username")
const Email = document.getElementById("email")
const Password = document.getElementById("password2")
const Password2 = document.getElementById("password2")
const btn_submit = document.getElementById("submit")
Form.onsubmit = (eventsubmit) => {
    eventsubmit.preventDefault();
    checkRequired([username, email, password, password2]);
    checkLength(username, 3, 15);
    checkLength(password, 6, 20);
    checkEmail(email);
    checkPassword(password, password2);

}
function checkRequired(inputArray) {
    inputArray.forEach(element => {
        if (element.value.trim() === "") {
            showError(element, "input is required")
        } else showSuccess(element)
    });
}
function checkLength(input, mix, min) {
    if (input.value.length < min) {
        showError(input, `${getFieldName(input)} must be at least ${min} characters`)
    }
    else if (input.value.length > mix) {
        showError(input, `${getFieldName(input)} must be less than ${max} characters`)
    }
    else showSuccess(input)
}
function CheckEmail(input) {
    const re = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
    if (re.test(input.value)) {
        showError(input, " email is not valid")
    }
    else showSuccess(input)
}
function checkPassword(pass1,pass2) {
if (pass1.value===pass2.value) {
    showSuccess(input)
}else showError(pass2, "passwords not matched")
}
function ShowSuccess(input) {
 onst
}
function ShowError() {

}
function getFieldName(input) {
    String(input.value).charAt(0).toUpperCase() + String(input.value).slice(1)
}












