const interval_ms = 1000 / 60;
let timerID;
let lastTimerstarttime = 0;
let millisElapesedBeforeLAstStart = 0;
//elements
const timer = document.getElementById("timer");
const start_button = document.getElementById("start-button");
const stop_button = document.getElementById("stop-button");
const reset_button = document.getElementById("reset-button");
//event
start_button.onclick = startTimer;
stop_button.onclick = stopTimer;
reset_button.onclick = resetTimer;
function startTimer() {
    start_button.disabled = true;
    stop_button.disabled = false;
    reset_button.disabled = true;
    lastTimerstarttime = Date.now()
    timerID = setInterval(updateTimer, interval_ms);
}
function stopTimer() {
    start_button.disabled = false;
    stop_button.disabled = true;
    reset_button.disabled = false;
    millisElapesedBeforeLAstStart += Date.now()-lastTimerstarttime
    clearInterval(timerID)
}
function resetTimer() {
    reset_button.disabled = true;
    timer.textContent = "00:00:00";
    millisElapesedBeforeLAstStart = 0;
}
function updateTimer() {
    const milllisElapesed = Date.now() - lastTimerstarttime + millisElapesedBeforeLAstStart;
    const secondElapesed = milllisElapesed / 1000;
    const mintesElapesed = secondElapesed / 60;
    const hourElapesed = mintesElapesed / 60;
    const milllisText = formatText(milllisElapesed % 1000,3);
    const secondText = formatText(Math.floor(secondElapesed) % 60,2);
    const minuteText = formatText(Math.floor(mintesElapesed)%60, 2);
    const hourText = formatText(Math.floor(hourElapesed), 2);
    timer.textContent = `${hourText}:${minuteText}:${secondText}:${milllisText}`
}
function formatText(text ,length) {
    const content = String(text)
    if (content.length > length)
      return  content.slice(0, length)
    return content.padStart(length,'0')
}