let display_input = document.getElementById('calcinput');
let point = document.getElementById('point');
let dis = String(display_input.value);
function appendToDisplay(input) {
    if (display_input.value.includes("Error")) {
        display_input.value = "";
    }
    display_input.value += input;

}
// function clear() {
//     display_input.value = "";
// }
function calcres() {
    try {
        display_input.value = eval(display_input.value);
    } catch (error) {
        display_input.value = "Error";
    }
}