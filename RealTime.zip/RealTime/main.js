const textarea = document.getElementById("textarea")
const remaining_counter = document.getElementById("remaining-counter")
const total_counter = document.getElementById("total-counter")
// let length_of_textarea;
// textarea.onkeyup = () =>
// {
//     length_of_textarea = textarea.value;
//     total_counter.innerHTML = length_of_textarea.length
//     remaining_counter.innerHTML = 50 - length_of_textarea.length
// }
// if (textarea.value === "") {
//     total_counter.innerHTML = 0
//     remaining_counter.innerHTML = 50
// }
remaining_function()
textarea.addEventListener("input", remaining_function)
function remaining_function() {
    let length_of_textarea = textarea.value.length;
    total_counter.innerHTML = length_of_textarea
    // remaining_counter.innerHTML = 50 - length_of_textarea
    remaining_counter.innerHTML = textarea.getAttribute("maxlength") - length_of_textarea
}